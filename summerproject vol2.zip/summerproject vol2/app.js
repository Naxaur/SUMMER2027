import express from "express";
import users from "./appUsers.js";
import trips from "./appTrips.js";

const app = express();
const PORT = 3000;

app.use(express.json()); 
app.use(express.static("index")); // Frontend fájlok elérése

app.use("/api/users", users);
app.use("/api/trips", trips);

app.listen(PORT, () => {
  console.log(`SUMMER2027 szerver fut: http://localhost:${PORT}`);
});