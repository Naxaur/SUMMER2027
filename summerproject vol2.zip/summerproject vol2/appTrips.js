import express from "express"; 
import * as db from "./data/dbTrips.js"; 

const router = express.Router(); // <-- ennek az a feladata hogy nem kell egybesűríteni mindent az app.js-be

// Publikus nyaralások lekérése 
router.get("/public", (req, res) => {
  const trips = db.GetAllPublicTrips();
  res.status(200).json(trips);
});

// Egy felhasználó saját posztjainak lekérése
router.get("/user/:userId", (req, res) => {
  const userId = Number(req.params.userId);
  const trips = db.GetAllUserTrips(userId);
  res.status(200).json(trips);
});

// Új nyaralás poszt létrehozása
router.post("/", (req, res) => {
  const { userId, username, place, tripTime, activities, accommodation, placesToVisit, foodSpots, otherTips, imageUrl, isPublic } = req.body;

  // mezők ellenőrzése
  if (!userId || !username || !place || !tripTime || !activities || !accommodation || !placesToVisit || !foodSpots || isPublic === undefined) {
    return res.status(400).json({ message: "Minden kötelező mezőt tölts ki!" });
  }

  // Mentés az adatbázisba
  const saved = db.SaveUserTrip(
    Number(userId),
    username,
    place,
    tripTime,
    activities,
    accommodation,
    placesToVisit,
    foodSpots,
    otherTips || "",
    imageUrl || "",
    Number(isPublic)
  );

  res.status(201).json({ message: "Trip saved", id: saved.lastInsertRowid });
});

// Saját poszt módosítása
router.put("/:userId/:id", (req, res) => {
  const userId = Number(req.params.userId);
  const id = Number(req.params.id);
  const { place, tripTime, activities, accommodation, placesToVisit, foodSpots, otherTips, imageUrl, isPublic } = req.body;

  if (!place || !tripTime || !activities || !accommodation || !placesToVisit || !foodSpots || isPublic === undefined) {
    return res.status(400).json({ message: "Hiányzó adat!" });
  }

  // Ellenőrizzük hogy létezik-e a poszt a felhasználóé-e
  const existing = db.GetUserTripById(userId, id);
  if (!existing) {
    return res.status(404).json({ message: "Poszt nem található vagy nem a te posztod!" });
  }

  // Módosítás mentése
  db.UpdateUserTrip(
    userId,
    id,
    place,
    tripTime,
    activities,
    accommodation,
    placesToVisit,
    foodSpots,
    otherTips || "",
    imageUrl || "",
    Number(isPublic)
  );

  res.status(200).json({ message: "Trip updated" });
});

// Saját poszt törlése
router.delete("/:userId/:id", (req, res) => {
  const userId = Number(req.params.userId);
  const id = Number(req.params.id);

  const existing = db.GetUserTripById(userId, id);
  if (!existing) {
    return res.status(404).json({ message: "Poszt nem található vagy nem a te posztod!" });
  }

  db.DeleteUserTrip(userId, id);
  res.status(200).json({ message: "Trip deleted" });
});

export default router; //itt exportáljuk az app.js-be meg birjuk majd importalni a faljt