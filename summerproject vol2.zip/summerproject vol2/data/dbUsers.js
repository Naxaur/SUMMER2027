import Database from "better-sqlite3"; 

const db = new Database("./data/users.db"); 

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
  )
`);

//összes user lekérése jelszó nélkül
export const GetAllUsers = () =>
  db.prepare(`SELECT id, username, email FROM users`).all();

//user keresése id alapján
export const GetUserById = (id) =>
  db.prepare(`SELECT id, username, email FROM users WHERE id = ?`).get(id);

//user keresése email alapján (belépéshez és ellenőrzéshez)
export const GetUserByEmail = (email) =>
  db.prepare(`SELECT id, username, email FROM users WHERE email = ?`).get(email);

//jelszó lekérése id alapján
export const GetPwById = (id) =>
  db.prepare(`SELECT password FROM users WHERE id = ?`).get(id)?.password;

//uj felhasználó mentése
export const SaveUser = (username, email, password) =>
  db.prepare(`INSERT INTO users (username, email, password) VALUES (?, ?, ?)`).run(username, email, password);