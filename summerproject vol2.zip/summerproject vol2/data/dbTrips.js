import Database from "better-sqlite3"; 

const db = new Database("./data/trips.db"); 

db.exec(`
  CREATE TABLE IF NOT EXISTS trips (
    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Egyedi azonosító, magától nő
    userId INTEGER NOT NULL, -- A posztot létrehozó felhasználó ID-ja
    username TEXT NOT NULL, -- A posztoló felhasználóneve a kártya tetejéhez
    place TEXT NOT NULL, -- Nyaralás helye
    tripTime TEXT NOT NULL, -- Nyaralás időpontja / hossza
    activities TEXT NOT NULL, -- Tevékenységek
    accommodation TEXT NOT NULL, -- Szállás
    placesToVisit TEXT NOT NULL, -- Places to visit (látnivalók)
    foodSpots TEXT NOT NULL, -- Kajáldák / Éttermek
    otherTips TEXT DEFAULT '', -- Egyéb tippek (opcionális)
    imageUrl TEXT DEFAULT '', -- Opcionális nyári kép URL
    isPublic INTEGER NOT NULL DEFAULT 1 -- 1 = publikus, 0 = privát
  )
`);

//összes publikus poszt:
export const GetAllPublicTrips = () =>
  db.prepare(`SELECT * FROM trips WHERE isPublic = 1 ORDER BY id DESC`).all();

//egy felhasználó posztjai 
export const GetAllUserTrips = (userId) =>
  db.prepare(`SELECT * FROM trips WHERE userId = ? ORDER BY id DESC`).all(userId);

//egy poszt lekérése ID és userId alapján 
export const GetUserTripById = (userId, id) =>
  db.prepare(`SELECT * FROM trips WHERE id = ? AND userId = ?`).get(id, userId);

//nyaralás poszt beszúrása az adatbázisba
export const SaveUserTrip = (
  userId,
  username,
  place,
  tripTime,
  activities,
  accommodation,
  placesToVisit,
  foodSpots,
  otherTips,
  imageUrl,
  isPublic
) =>
  db.prepare(`
    INSERT INTO trips (userId, username, place, tripTime, activities, accommodation, placesToVisit, foodSpots, otherTips, imageUrl, isPublic)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(userId, username, place, tripTime, activities, accommodation, placesToVisit, foodSpots, otherTips, imageUrl, isPublic);

//poszt frissítése (saját!!!) 
export const UpdateUserTrip = (
  userId,
  id,
  place,
  tripTime,
  activities,
  accommodation,
  placesToVisit,
  foodSpots,
  otherTips,
  imageUrl,
  isPublic
) =>
  db.prepare(`
    UPDATE trips
    SET place = ?, tripTime = ?, activities = ?, accommodation = ?, placesToVisit = ?, foodSpots = ?, otherTips = ?, imageUrl = ?, isPublic = ?
    WHERE id = ? AND userId = ?
  `).run(place, tripTime, activities, accommodation, placesToVisit, foodSpots, otherTips, imageUrl, isPublic, id, userId);

//poszt törlése (saját!!!)
export const DeleteUserTrip = (userId, id) =>
  db.prepare(`DELETE FROM trips WHERE id = ? AND userId = ?`).run(id, userId);