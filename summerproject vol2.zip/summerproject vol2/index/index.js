let currentUser = null; // be van e jelentkezve?

const authToggleBtn = document.getElementById("authToggleBtn");
const authHeaderText = document.getElementById("authHeaderText");
const authPanel = document.getElementById("authPanel");
const loginBox = document.getElementById("loginBox");
const registerBox = document.getElementById("registerBox");

const userSection = document.getElementById("userSection");
const userTrips = document.getElementById("userTrips");
const publicTrips = document.getElementById("publicTrips");
const message = document.getElementById("message");

// ki-bejelentekezsés gomb
authToggleBtn.onclick = () => {
  if (currentUser) {
    logoutUser(); 
    return;
  }
  loginBox.hidden = false; // Alapból a bejelentkezés nézet jelenik meg
  registerBox.hidden = true;
  authPanel.hidden = false;
};

// kicsi x
document.getElementById("closeAuthBtn").onclick = () => {
  authPanel.hidden = true;
};

document.getElementById("closeRegBtn").onclick = () => {
  authPanel.hidden = true;
};

// Átváltás bejelentkezésről regisztrációra
document.getElementById("goToRegister").onclick = (e) => {
  e.preventDefault();
  loginBox.hidden = true;
  registerBox.hidden = false;
};

// forditva
document.getElementById("goToLogin").onclick = (e) => {
  e.preventDefault();
  registerBox.hidden = true;
  loginBox.hidden = false;
};

// nyaralo kartya:
function createTripCard(trip, editable = false) {
  const column = document.createElement("div");
  column.className = "col-12 col-sm-6 col-lg-4";

  const card = document.createElement("div");
  card.className = "trip-card";

  // kartya teteje:
  const authorBar = document.createElement("div");
  authorBar.className = "trip-author";
  authorBar.innerHTML = `
    <span class="avatar-circle" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
        <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/>
      </svg>
    </span>
    <span>${trip.username}</span>
  `;
  card.appendChild(authorBar);

  // kép (ha van)
  if (trip.imageUrl && trip.imageUrl.trim() !== "") {
    const img = document.createElement("img");
    img.className = "trip-photo";
    img.src = trip.imageUrl.trim();
    img.alt = trip.place;
    img.onerror = () => {
      img.remove();
    };
    card.appendChild(img);
  }

  // Helyszín cím
  const title = document.createElement("h3");
  title.textContent = trip.place;
  card.appendChild(title);

  // kitöltött adatok:
  const fields = [
    ["Időszak", "tripTime"],
    ["Tevékenységek", "activities"],
    ["Szállás", "accommodation"],
    ["Látogatni való helyek", "placesToVisit"],
    ["Éttermek", "foodSpots"],
    ["Egyéb tippek", "otherTips"]
  ];

  // uj sor minden infonak
  fields.forEach(([label, key]) => {
    if (key === "otherTips" && (!trip[key] || trip[key].trim() === "")) {
      return;
    }
    const p = document.createElement("p");
    p.innerHTML = `<b>${label}:</b> ${trip[key]}`;
    card.appendChild(p);
  });

  // állapotot, módosítás/törlés gombok
  if (editable) {
    const status = document.createElement("p");
    status.innerHTML = `<small><b>Állapot:</b> ${trip.isPublic ? "Publikus" : "Privát"}</small>`;
    card.appendChild(status);

    const buttons = document.createElement("div");
    buttons.className = "trip-buttons";

    // Módosítás gomb
    const editBtn = document.createElement("button");
    editBtn.textContent = "Módosítás";
    editBtn.onclick = () => {
      card.innerHTML = ""; // ha ranyomunk az edit gombra ures inputmezok lesznek

      const placeInput = document.createElement("input");
      placeInput.className = "form-control mb-2";
      placeInput.placeholder = "Hol jártál?";
      placeInput.value = trip.place;
      card.appendChild(placeInput);

      const inputs = {};
      fields.forEach(([label, key]) => {
        const input = document.createElement("input");
        input.className = "form-control mb-2";
        input.placeholder = label;
        input.value = trip[key] || "";
        inputs[key] = input;
        card.appendChild(input);
      });

      const imgInput = document.createElement("input");
      imgInput.className = "form-control mb-2";
      imgInput.type = "url";
      imgInput.placeholder = "Kép URL (opcionális)";
      imgInput.value = trip.imageUrl || "";
      card.appendChild(imgInput);

      const publicSelect = document.createElement("select");
      publicSelect.className = "form-select mb-2";
      publicSelect.innerHTML = `
        <option value="1">Publikus</option>
        <option value="0">Privát</option>
      `;
      publicSelect.value = trip.isPublic;
      card.appendChild(publicSelect);

      const controls = document.createElement("div");
      controls.className = "trip-buttons";

      // Mentés gomb
      const saveBtn = document.createElement("button");
      saveBtn.textContent = "Mentés";
      saveBtn.onclick = () => {
        fetch(`/api/trips/${currentUser.id}/${trip.id}`, { //put kérés küldése 
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            place: placeInput.value,
            tripTime: inputs.tripTime.value,
            activities: inputs.activities.value,
            accommodation: inputs.accommodation.value,
            placesToVisit: inputs.placesToVisit.value,
            foodSpots: inputs.foodSpots.value,
            otherTips: inputs.otherTips.value,
            imageUrl: imgInput.value,
            isPublic: Number(publicSelect.value)
          })
        })
          .then((res) => res.json())
          .then((data) => {
            if (data.message === "Trip updated") {
              loadUserTrips();
              loadPublicTrips();
            } else {
              alert(data.message || "Nem sikerült a módosítás!");
            }
          });
      };

      // Mégse gomb 
      const cancelBtn = document.createElement("button");
      cancelBtn.textContent = "Mégse";
      cancelBtn.onclick = loadUserTrips;

      controls.append(saveBtn, cancelBtn);
      card.appendChild(controls);
    };

    // Törlés gomb 
    const delBtn = document.createElement("button");
    delBtn.textContent = "Törlés";
    delBtn.onclick = () => {
      if (confirm("Biztosan törlöd ezt a posztot?")) {
        fetch(`/api/trips/${currentUser.id}/${trip.id}`, { //delete kérés küldése
          method: "DELETE"
        })
          .then((res) => res.json())
          .then(() => {
            loadUserTrips();
            loadPublicTrips();
          });
      }
    };

    buttons.append(editBtn, delBtn);
    card.appendChild(buttons);
  }

  column.appendChild(card);
  return column;
}

// get public posztok 
function loadPublicTrips() {
  fetch("/api/trips/public")
    .then((res) => res.json())
    .then((data) => {
      publicTrips.innerHTML = "";
      data.forEach((trip) => {
        publicTrips.appendChild(createTripCard(trip, false));
      });
    });
}

// get user own post
function loadUserTrips() {
  if (!currentUser) return;
  fetch(`/api/trips/user/${currentUser.id}`)
    .then((res) => res.json())
    .then((data) => {
      userTrips.innerHTML = "";
      data.forEach((trip) => {
        userTrips.appendChild(createTripCard(trip, true));
      });
    });
}

// felhasznalo regisztralasa az adatbazisba
document.getElementById("registerForm").onsubmit = (e) => {
  e.preventDefault();
  fetch("/api/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: document.getElementById("regUsername").value,
      email: document.getElementById("regEmail").value,
      password: document.getElementById("regPassword").value
    })
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.id) {
        message.textContent = "Sikeres regisztráció. Most már bejelentkezhetsz.";
        message.style.color = "green";
        e.target.reset();
        registerBox.hidden = true;
        loginBox.hidden = false;
      } else {
        message.textContent = data.message || "Sikertelen regisztráció.";
        message.style.color = "red";
      }
    });
};

// felhasznalo bejelentkezese az oldalra
document.getElementById("loginForm").onsubmit = (e) => {
  e.preventDefault();
  fetch("/api/users/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: document.getElementById("loginEmail").value,
      password: document.getElementById("loginPassword").value
    })
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.id) {
        currentUser = data;
        authPanel.hidden = true;
        userSection.hidden = false;
        authHeaderText.textContent = `${data.username} (kilépés)`;
        document.getElementById("welcome").textContent = "Szia, " + data.username;
        message.textContent = "";
        e.target.reset();
        loadUserTrips();
      } else {
        message.textContent = data.message || "Hibás e-mail cím vagy jelszó.";
        message.style.color = "red";
      }
    });
};

// Új nyaralás poszt mentése
document.getElementById("tripForm").onsubmit = (e) => {
  e.preventDefault();
  fetch("/api/trips", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      userId: currentUser.id,
      username: currentUser.username,
      place: document.getElementById("place").value,
      tripTime: document.getElementById("tripTime").value,
      activities: document.getElementById("activities").value,
      accommodation: document.getElementById("accommodation").value,
      placesToVisit: document.getElementById("placesToVisit").value,
      foodSpots: document.getElementById("foodSpots").value,
      otherTips: document.getElementById("otherTips").value,
      imageUrl: document.getElementById("imageUrl").value,
      isPublic: Number(document.getElementById("isPublic").value)
    })
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.message === "Trip saved") {
        e.target.reset();
        message.textContent = "Nyaralás poszt elmentve.";
        message.style.color = "green";
        loadUserTrips();
        loadPublicTrips();
      } else {
        message.textContent = data.message || "Nem sikerült a mentés.";
        message.style.color = "red";
      }
    });
};

// Kijelentkezés
function logoutUser() {
  currentUser = null;
  authHeaderText.textContent = "regisztráció/bejelentkezés";
  userTrips.innerHTML = "";
  message.textContent = "";                               // oldal alaphelyzetbe állítása
  userSection.hidden = true;
  document.querySelectorAll("form").forEach((form) => form.reset());
  loadPublicTrips();
}

loadPublicTrips(); // oldal betöltésekr csak publikus posztok jelennek meg