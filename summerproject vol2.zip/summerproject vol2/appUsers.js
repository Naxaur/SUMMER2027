import bcrypt from "bcrypt";
import express from "express";
import * as db from "./data/dbUsers.js";

const router = express.Router();

// Új felhasználó regisztrálása
router.post("/", (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ message: "Hiányzó adat!" });
  }

  try {
    // Jelszó sózása és hashelése
    const salt = bcrypt.genSaltSync();
    const hashedPassword = bcrypt.hashSync(password, salt);

    const saved = db.SaveUser(username, email, hashedPassword);
    const user = db.GetUserById(saved.lastInsertRowid);
    res.status(201).json(user);
  } catch {
    //hiba, ha az email vagy username már létezik
    res.status(400).json({ message: "Ez a felhasználónév vagy e-mail már foglalt!" });
  }
});

// Bejelentkezés
router.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: "Hibás belépési adatok!" });
  }

  const user = db.GetUserByEmail(email);
  if (!user) {
    return res.status(400).json({ message: "Hibás belépési adatok!" });
  }

  const storedHash = db.GetPwById(user.id);
  if (!bcrypt.compareSync(password, storedHash)) {
    return res.status(400).json({ message: "Hibás belépési adatok!" });
  }

  res.status(200).json(user);
});

export default router;